package com.defbianisti.kuis_1_21103094;

public class Penduduk_21103094 {

    String nik;
    String nama;
    int umur;
    String alamat;

    public void tampilDataPenduduk() {
        System.out.println("Data Penduduk : ");
        System.out.println();
        System.out.println("NIK : " + nik);
        System.out.println("Nama : " + nama);
        System.out.println("Umur : " + umur);
        System.out.println("Alamat : " + alamat);

    }

}
